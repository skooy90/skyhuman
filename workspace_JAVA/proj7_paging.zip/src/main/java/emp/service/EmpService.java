package emp.service;

import java.util.List;

import emp.DAO2.EmpDAO;
import emp.DTO2.EmpDTO;

public class EmpService {
	EmpDAO empDAO = new EmpDAO();

	public List getAllEmp(){
		List<EmpDTO> list = empDAO.selectAllEmp();
		return list;
	}
	public EmpDTO getOneEmp(EmpDTO empDTO) {
		EmpDTO dto = empDAO.selectOneEmp(empDTO);
		return dto;
	}
	public int removeEmp(EmpDTO empDTO) {
		return empDAO.deleteEmp(empDTO);
	}
	public int addEmp(EmpDTO empDTO) {
		return empDAO.insertEmp(empDTO);
	}
	public int editEmp(EmpDTO empDTO) {
		return empDAO.updateEmp(empDTO);
	}
	
}
