package emp.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import emp.DTO2.EmpDTO;
import emp.service.EmpService;

@WebServlet("/list")
public class EmpListController extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset=utf-8;");

		System.out.println("doGet 실행");
		int empno = 0;

		// 파라메터 empno를 int로 형변환
		try {
			String strEmpno = request.getParameter("empno");
			if (strEmpno != null) {
				empno = Integer.parseInt(strEmpno);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			
			EmpDTO dTO = new EmpDTO();
			dTO.setEmpno(empno);
			
			EmpService service = new EmpService();
			List<EmpDTO> list = service.getAllEmp();
			
			request.setAttribute("list", list);
			
			RequestDispatcher dis = request.getRequestDispatcher("paging.jsp");
			dis.forward(request, response);
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	 
}
