package sec02.exam01;

public interface Keyboard {

	String press(int keyCode);
	
	
}
