package sec02.exam01;

public class MemberDTO {

	
	String name;
	int age;
	
	
}
