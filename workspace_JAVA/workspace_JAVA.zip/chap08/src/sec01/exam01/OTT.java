package sec01.exam01;

public interface OTT {
	void netflix();
	
}
